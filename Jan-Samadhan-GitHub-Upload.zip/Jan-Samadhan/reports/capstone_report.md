# Jan-Samadhan — Capstone Case Study Report

## Executive summary
Jan-Samadhan is a proof-of-concept pipeline for grievance analytics, department routing, privacy-aware text handling and SOP-grounded officer assistance. It uses 500 synthetic records and a fictional SOP; it does not use actual CPGRAMS records or official policy material.

## Problem statement
Manual reading, categorization, urgency assessment and response drafting can contribute to grievance backlogs. The prototype demonstrates data analytics, supervised ML and retrieval-grounded assistance while preserving human authority.

## Dataset and preparation
The CSV contains 500 synthetic records with complaint ID, state, submission date, department, status, resolution days, urgency and complaint description. Metadata fields are structured; the complaint narrative is unstructured. Missing narratives are converted to empty strings. Text is lowercased, whitespace normalized and nonessential special characters removed.

## Phase 1 — Data exploration
The pipeline generates a top-five department chart, monthly complaint-volume trend and average resolution days for records marked Resolved with a recorded duration. Run `python -m src.train` to generate charts and summary outputs.

## Phase 2 — Predictive ML
A supervised classifier predicts the department using word- and character-level TF-IDF features followed by Logistic Regression. The split is 80/20 and stratified by department with random seed 42. Accuracy, classification report and confusion matrix are saved to `reports/model_metrics.json`.

### Why Logistic Regression instead of training DNN/BERT from scratch?
The sample is small and synthetic, so a large neural model trained from scratch would be prone to overfitting and would require substantially more labelled data, compute and tuning. TF-IDF with Logistic Regression is fast, reproducible and a sensible baseline for sparse text features. A pretrained transformer could be evaluated later with representative, approved multilingual data, but would still require validation and governance. Synthetic-data metrics do not establish production readiness.

## Phase 3 — GenAI and RAG
The C.R.O.S.S. prompt is documented in `docs/cross_system_prompt.md`. The mini-RAG retrieves passages from a fictional SOP using TF-IDF similarity and abstains when no relevant passage is found. The local dashboard provides a deterministic illustrative summary, sentiment/urgency labels and acknowledgment draft; no external LLM is called.

## Phase 4 — Governance, ethics and security
Regex masking demonstrates protection for common Aadhaar-like IDs, Indian mobile numbers and email addresses. It is not a complete PII detector. The risk assessment covers prompt injection and regional-language bias, with mitigations including input isolation, least privilege, multilingual evaluation, manual review and human approval.

## Results and reproducibility
Run `python -m src.train` to generate `reports/model_metrics.json` and visualizations. Record the observed accuracy from that file in any presentation. As the dataset is synthetic, metrics demonstrate the workflow only and do not estimate real CPGRAMS performance.

## Conclusion
The PoC demonstrates a reproducible flow across analytics, supervised routing, local SOP retrieval and governance. Operational deployment would require authorized real data, representative multilingual labels, formal security/privacy review, auditability and mandatory officer oversight.
