"""Local TF-IDF retrieval demo over a fictional SOP. No external API is called."""
from pathlib import Path
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from .config import SOP_PATH
from .privacy import mask_pii

def chunk_text(text, max_words=90):
    words = text.split()
    return [" ".join(words[i:i + max_words]) for i in range(0, len(words), max_words)]

class LocalSOPRetriever:
    def __init__(self, path=SOP_PATH):
        raw = Path(path).read_text(encoding="utf-8")
        self.chunks = chunk_text(raw)
        self.vectorizer = TfidfVectorizer(stop_words="english", ngram_range=(1, 2))
        self.matrix = self.vectorizer.fit_transform(self.chunks)

    def retrieve(self, query, top_k=2):
        query_vec = self.vectorizer.transform([mask_pii(query)])
        scores = cosine_similarity(query_vec, self.matrix).ravel()
        indices = scores.argsort()[::-1][:top_k]
        return [(self.chunks[i], float(scores[i]))
                for i in indices if scores[i] > 0.02]

    def answer(self, query):
        matches = self.retrieve(query)
        if not matches:
            return ("The supplied demonstration SOP does not contain enough information "
                    "to answer this query. Please refer it to the authorized officer."), []
        q = query.lower()
        combined = " ".join(chunk for chunk, _ in matches).lower()
        if any(term in q for term in ["status", "track", "progress"]):
            if "status can be checked" in combined:
                answer = ("The fictional SOP says status can be checked using the complaint "
                          "reference number through the designated grievance channel.")
            else:
                answer = "The supplied SOP does not specify this. Please refer it to the authorized officer."
        elif any(term in q for term in ["document", "proof", "supporting"]):
            if "supporting documents" in combined:
                answer = ("The fictional SOP says the citizen should provide a concise issue "
                          "description and supporting documents, if available.")
            else:
                answer = "The supplied SOP does not specify this. Please refer it to the authorized officer."
        elif any(term in q for term in ["review", "appeal", "dissatisfied"]):
            if "request a review" in combined:
                answer = ("The fictional SOP says a dissatisfied citizen may request a review "
                          "through the designated grievance officer. It does not specify a timeline.")
            else:
                answer = "The supplied SOP does not specify this. Please refer it to the authorized officer."
        else:
            answer = ("The retrieved fictional SOP passages have been provided as evidence. "
                      "Please have an authorized officer interpret them; no additional rule is inferred.")
        return answer, matches
