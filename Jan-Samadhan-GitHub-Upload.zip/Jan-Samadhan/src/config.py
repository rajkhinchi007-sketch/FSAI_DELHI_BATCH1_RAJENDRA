from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = ROOT / "data" / "grievances_synthetic.csv"
MODEL_DIR = ROOT / "models"
REPORT_DIR = ROOT / "reports"
SOP_PATH = ROOT / "docs" / "fictional_sop.md"
RANDOM_STATE = 42
