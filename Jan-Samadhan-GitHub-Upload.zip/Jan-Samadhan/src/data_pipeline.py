import re
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from .config import DATA_PATH, REPORT_DIR

STRUCTURED_COLUMNS = [
    "complaint_id", "state", "submission_date", "department",
    "status", "resolution_days", "urgency"
]
UNSTRUCTURED_COLUMNS = ["complaint_description"]

def clean_text(value):
    if pd.isna(value):
        return ""
    value = str(value).lower()
    value = re.sub(r"\s+", " ", value)
    value = re.sub(r"[^\w\s.,!?/-]", " ", value)
    return value.strip()

def load_and_clean(path=DATA_PATH):
    df = pd.read_csv(path)
    for col in ["state", "department", "status", "urgency"]:
        df[col] = df[col].fillna("Unknown").astype(str).str.strip()
    df["complaint_description"] = df["complaint_description"].apply(clean_text)
    df["submission_date"] = pd.to_datetime(df["submission_date"], errors="coerce")
    df["resolution_days"] = pd.to_numeric(df["resolution_days"], errors="coerce")
    df["month"] = df["submission_date"].dt.to_period("M").astype(str)
    return df

def create_visualizations(df, output_dir=REPORT_DIR):
    output_dir.mkdir(parents=True, exist_ok=True)
    sns.set_theme(style="whitegrid")
    top = df["department"].value_counts().head(5)
    fig, ax = plt.subplots(figsize=(9, 5))
    sns.barplot(x=top.values, y=top.index, ax=ax)
    ax.set(title="Top 5 Departments by Complaint Volume",
           xlabel="Number of complaints", ylabel="Department")
    fig.tight_layout()
    top_path = output_dir / "top5_departments.png"
    fig.savefig(top_path, dpi=160)
    plt.close(fig)

    monthly = df.groupby("month").size().sort_index()
    fig, ax = plt.subplots(figsize=(10, 5))
    monthly.plot(ax=ax, marker="o")
    ax.set(title="Monthly Complaint Volume Trend",
           xlabel="Month", ylabel="Complaints")
    ax.tick_params(axis="x", rotation=45)
    fig.tight_layout()
    trend_path = output_dir / "monthly_trend.png"
    fig.savefig(trend_path, dpi=160)
    plt.close(fig)

    resolved = df.loc[df["status"].eq("Resolved"), "resolution_days"].dropna()
    avg_days = float(resolved.mean()) if len(resolved) else None
    return {
        "top5": top.to_dict(),
        "average_resolution_days": avg_days,
        "top5_chart": str(top_path),
        "trend_chart": str(trend_path)
    }
