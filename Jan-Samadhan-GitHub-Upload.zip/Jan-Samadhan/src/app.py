import joblib
import gradio as gr
from .config import MODEL_DIR
from .data_pipeline import load_and_clean, create_visualizations
from .privacy import mask_pii
from .rag import LocalSOPRetriever

MODEL_PATH = MODEL_DIR / "department_router.joblib"
if not MODEL_PATH.exists():
    raise SystemExit("Model not found. First run: python -m src.train")

model = joblib.load(MODEL_PATH)
df = load_and_clean()
retriever = LocalSOPRetriever()

def analytics():
    result = create_visualizations(df)
    avg = result["average_resolution_days"]
    avg_text = f"{avg:.1f} days" if avg is not None else "Not available"
    text = (f"**Dataset rows:** {len(df)}  \n"
            f"**Departments:** {df.department.nunique()}  \n"
            f"**Average resolution time among resolved records:** {avg_text}")
    return text, result["top5_chart"], result["trend_chart"]

def route_complaint(text):
    if not text or not text.strip():
        return "Please enter a complaint.", ""
    safe_text = mask_pii(text)
    predicted = model.predict([safe_text])[0]
    probabilities = model.predict_proba([safe_text])[0]
    confidence = max(probabilities) * 100
    return predicted, f"{confidence:.1f}% — model confidence, not a correctness guarantee"

def officer_copilot(text):
    if not text or not text.strip():
        return "", "", "", "", ""
    safe_text = mask_pii(text)
    lower = safe_text.lower()
    high_terms = ["danger", "accident", "ambulance", "threat", "unsafe",
                  "injury", "fire", "electrocution"]
    medium_terms = ["delay", "pending", "not received", "stopped", "unresolved"]
    urgency = ("High" if any(term in lower for term in high_terms)
               else "Medium" if any(term in lower for term in medium_terms)
               else "Low")
    negative_terms = ["angry", "frustrated", "not received", "failed",
                      "delay", "unresolved", "disappointed"]
    sentiment = "Negative" if any(term in lower for term in negative_terms) else "Neutral / mixed"
    summary = (
        "The citizen reports a service-delivery concern and requests action from the concerned department. "
        "The matter should be checked against relevant records and routed to the responsible authority."
    )
    acknowledgement = (
        "Dear Citizen,\n\nYour grievance has been received. We regret the inconvenience caused. "
        "The concerned office will be requested to examine the matter and verify the available records. "
        "Please retain your complaint reference number for future correspondence.\n\n"
        "Regards,\nGrievance Facilitation Desk\n\n(Draft — officer verification required)"
    )
    answer, evidence = retriever.answer(safe_text)
    evidence_text = "\n\n".join(
        f"Similarity {score:.2f}: {chunk[:400]}..." for chunk, score in evidence
    ) if evidence else "No sufficiently relevant SOP passage retrieved."
    return summary, f"Sentiment: {sentiment}\nUrgency: {urgency}", acknowledgement, answer, evidence_text

with gr.Blocks(title="Jan-Samadhan | Citizen Grievance Co-Pilot",
               theme=gr.themes.Soft()) as demo:
    gr.Markdown(
        "# 🇮🇳 Jan-Samadhan\n"
        "### Smart Citizen Grievance Redressal & Policy Assistant\n"
        "**Synthetic-data demonstration only. Not an official CPGRAMS system. "
        "All outputs require authorized human review.**"
    )
    with gr.Tab("Data analytics"):
        refresh = gr.Button("Generate analytics", variant="primary")
        stats = gr.Markdown()
        top_chart = gr.Image(label="Top 5 departments", type="filepath")
        trend_chart = gr.Image(label="Monthly complaint volume trend", type="filepath")
        refresh.click(analytics, outputs=[stats, top_chart, trend_chart])
    with gr.Tab("ML department routing"):
        complaint = gr.Textbox(label="Complaint narrative", lines=5)
        predict_button = gr.Button("Predict department", variant="primary")
        department = gr.Textbox(label="Predicted department")
        confidence = gr.Textbox(label="Confidence")
        predict_button.click(route_complaint, inputs=complaint,
                             outputs=[department, confidence])
    with gr.Tab("Officer co-pilot + mini-RAG"):
        narrative = gr.Textbox(label="Complaint / question", lines=5)
        analyze_button = gr.Button("Analyze complaint", variant="primary")
        summary = gr.Textbox(label="Neutral two-sentence summary", lines=3)
        labels = gr.Textbox(label="Sentiment and urgency")
        acknowledgement = gr.Textbox(label="Acknowledgment draft", lines=7)
        answer = gr.Textbox(label="Answer using fictional SOP", lines=4)
        evidence = gr.Textbox(label="Retrieved SOP evidence", lines=6)
        analyze_button.click(
            officer_copilot, inputs=narrative,
            outputs=[summary, labels, acknowledgement, answer, evidence]
        )
    gr.Markdown(
        "---\n**Privacy:** common identifier patterns are masked locally before processing. "
        "Regex masking is not comprehensive. Do not enter real citizen data."
    )

if __name__ == "__main__":
    demo.launch(server_name="127.0.0.1", server_port=7860)
