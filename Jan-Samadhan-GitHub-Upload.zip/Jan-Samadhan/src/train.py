import json
import joblib
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline, FeatureUnion
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from .config import MODEL_DIR, REPORT_DIR, RANDOM_STATE
from .data_pipeline import load_and_clean, create_visualizations

def train():
    MODEL_DIR.mkdir(exist_ok=True)
    REPORT_DIR.mkdir(exist_ok=True)
    df = load_and_clean()
    usable = df[df["complaint_description"].str.len() > 0].copy()
    X_train, X_test, y_train, y_test = train_test_split(
        usable["complaint_description"], usable["department"],
        test_size=0.20, random_state=RANDOM_STATE, stratify=usable["department"]
    )
    model = Pipeline([
        ("features", FeatureUnion([
            ("word", TfidfVectorizer(ngram_range=(1, 2), max_features=12000,
                                     sublinear_tf=True)),
            ("char", TfidfVectorizer(analyzer="char", ngram_range=(3, 5),
                                     max_features=12000, min_df=2))
        ])),
        ("classifier", LogisticRegression(max_iter=1500, class_weight="balanced",
                                          random_state=RANDOM_STATE))
    ])
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)
    labels = sorted(usable["department"].unique())
    metrics = {
        "accuracy": float(accuracy_score(y_test, predictions)),
        "classification_report": classification_report(
            y_test, predictions, output_dict=True, zero_division=0
        ),
        "labels": labels,
        "confusion_matrix": confusion_matrix(y_test, predictions, labels=labels).tolist(),
        "train_rows": int(len(X_train)),
        "test_rows": int(len(X_test)),
        "note": "Synthetic-data metrics are for demonstration only."
    }
    joblib.dump(model, MODEL_DIR / "department_router.joblib")
    (REPORT_DIR / "model_metrics.json").write_text(
        json.dumps(metrics, indent=2), encoding="utf-8"
    )
    summary = create_visualizations(df)
    print(f"Dataset rows: {len(df)}; ML rows: {len(usable)}")
    print(f"Test accuracy: {metrics['accuracy']:.3f}")
    print("Top five departments:", summary["top5"])
    print("Average resolution days:", summary["average_resolution_days"])
    print("Model saved to models/department_router.joblib")
    print("Metrics saved to reports/model_metrics.json")
    return model, metrics, summary

if __name__ == "__main__":
    train()
