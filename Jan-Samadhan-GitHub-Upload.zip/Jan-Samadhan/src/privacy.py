import re

# Best-effort examples only. Not a complete PII detector.
AADHAAR_RE = re.compile(r"(?<!\d)(?:\d{4}[\s-]?){2}\d{4}(?!\d)")
PHONE_RE = re.compile(r"(?<!\d)(?:\+?91[\s-]?)?[6-9]\d{9}(?!\d)")
EMAIL_RE = re.compile(r"\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b", re.I)

def mask_pii(text: str) -> str:
    """Mask common Aadhaar-like 12-digit patterns, Indian mobile numbers and emails."""
    if not isinstance(text, str):
        text = str(text or "")
    text = AADHAAR_RE.sub("[MASKED_ID]", text)
    text = PHONE_RE.sub("[MASKED_PHONE]", text)
    text = EMAIL_RE.sub("[MASKED_EMAIL]", text)
    return text
