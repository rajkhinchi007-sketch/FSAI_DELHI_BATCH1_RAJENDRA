# Fictional Demonstration SOP — Grievance Facilitation

**Disclaimer:** This is fictional material created only for the capstone demonstration. It is not a Government of India, CPGRAMS, state-government or departmental order.

## 1. Receipt and reference
Every grievance received by the demonstration helpdesk is assigned a complaint reference number. The citizen should retain this number for future correspondence. Status can be checked using the complaint reference number through the designated grievance channel.

## 2. Supporting information
The citizen should provide a concise description of the issue, the relevant service or location, and supporting documents if available. Sensitive personal information should not be included unless specifically required through an approved secure channel.

## 3. Review and routing
The helpdesk should route the grievance to the responsible service department for examination. The receiving office should review available records and may seek clarification where necessary. This fictional SOP does not prescribe a statutory service deadline.

## 4. Escalation and review
If the citizen is dissatisfied with the recorded response, the citizen may request a review through the designated grievance officer. This fictional SOP does not specify an appeal timeline, statutory entitlement or final authority.

## 5. Human oversight
Automated classifications and generated drafts are advisory only. An authorized officer must verify facts, applicable rules and the proposed response before any official communication or decision.
