# Contributing

For this educational PoC, please:
- Do not commit real citizen grievance records or personally identifiable information.
- Keep synthetic/demo content clearly labelled.
- Add tests for data cleaning, PII masking and retrieval behavior when changing these modules.
- Document any model/data change and its evaluation limitations.
