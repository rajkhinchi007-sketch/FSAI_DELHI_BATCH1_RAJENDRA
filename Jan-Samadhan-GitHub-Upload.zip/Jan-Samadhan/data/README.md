# Dataset documentation

`grievances_synthetic.csv` contains 500 generated demonstration records. No real citizen information is used.

| Column | Description |
|---|---|
| complaint_id | Synthetic complaint identifier |
| state | Synthetic state label |
| submission_date | Synthetic submission date |
| department | Synthetic department/routing target |
| status | Resolved, Pending, In Progress or Escalated |
| resolution_days | Duration for resolved cases; blank otherwise |
| urgency | Illustrative urgency label |
| complaint_description | Synthetic narrative; selected rows contain test PII patterns for masking demonstration |

The sample is deterministic and is not official CPGRAMS data.
