# Jan-Samadhan — Smart Citizen Grievance Redressal & Policy Assistant

A complete, reproducible capstone proof-of-concept for grievance analytics, ML-based department routing, a local SOP retrieval demonstration, and privacy/governance controls.

**Dataset and policy disclaimer:** This repository contains 500 synthetic demonstration records and a fictional SOP. It does not contain actual CPGRAMS records or official Government of India policy. Outputs are advisory drafts; an authorized officer must verify every prediction and communication.

## Assignment coverage

| Required phase | Project implementation |
|---|---|
| Phase 1 — Data Exploration & Visualization | Pandas cleaning, structured/unstructured field identification, missing values, top-five department chart, monthly trend and average resolution time |
| Phase 2 — Predictive ML Modeling | TF-IDF + Logistic Regression, stratified train/test split, accuracy, classification report and confusion matrix |
| Phase 3 — GenAI & RAG Officer Co-Pilot | C.R.O.S.S. prompt, two-sentence neutral summary, sentiment/urgency, acknowledgment draft, local SOP retrieval and abstention |
| Phase 4 — Governance, Ethics & Security | Regex PII masking, prompt-injection risk, regional-language bias and mitigation controls |

## Quick start

Python 3.10–3.12 recommended.

### Windows PowerShell
```powershell
py -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
python -m src.train
python -m src.app
```

### macOS / Linux
```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
python -m src.train
python -m src.app
```

Open the local Gradio URL printed in the terminal (usually `http://127.0.0.1:7860`).

## Jupyter Notebook
```bash
pip install jupyter ipykernel
jupyter notebook
```
Open `notebooks/Jan_Samadhan_Capstone.ipynb` and run cells from top to bottom.

## Project structure
```text
Jan-Samadhan/
├── README.md
├── requirements.txt
├── LICENSE
├── .gitignore
├── data/
│   ├── grievances_synthetic.csv
│   └── README.md
├── docs/
│   ├── fictional_sop.md
│   ├── cross_system_prompt.md
│   └── governance_and_risk.md
├── models/                 # generated after training
├── notebooks/
│   └── Jan_Samadhan_Capstone.ipynb
├── reports/
│   └── capstone_report.md
└── src/
    ├── __init__.py
    ├── config.py
    ├── data_pipeline.py
    ├── privacy.py
    ├── rag.py
    ├── train.py
    └── app.py
```

## GitHub upload

1. Create a new empty repository on GitHub, e.g. `jan-samadhan`.
2. Extract the ZIP and open a terminal inside the extracted `Jan-Samadhan` folder.
3. Run:
```bash
git init
git add .
git commit -m "Initial Jan-Samadhan capstone project"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```
Replace the remote URL with your own GitHub repository URL. Or use GitHub → **Add file → Upload files** and upload the extracted folder contents.

## Important limitations
- Synthetic data only: metrics are a software demonstration, not evidence of real-world CPGRAMS accuracy.
- Regex PII masking is best-effort and may miss names, addresses, bank details, unusual phone formats and obfuscated values.
- The included SOP is fictional and must not be quoted as a government rule.
- The local RAG is a small TF-IDF retrieval demonstration, not a production vector database.
- The dashboard's co-pilot is deterministic and does not call an external LLM. The prompt specification is supplied for use with an approved model.
- Production use requires authorized representative data, multilingual evaluation, security/privacy assessment, audit logging, access controls, encryption, retention rules and mandatory human review.
