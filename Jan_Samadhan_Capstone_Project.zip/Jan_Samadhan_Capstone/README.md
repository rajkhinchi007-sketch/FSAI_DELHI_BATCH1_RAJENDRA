# Jan-Samadhan — Capstone PoC

## What is included
- `app.py`: Gradio dashboard, data cleaning, visualizations, TF-IDF + Logistic Regression models, C.R.O.S.S. prompt, PII masking, and SOP retrieval demo.
- `data/jan_samadhan_sample.csv`: 650 synthetic grievance records.
- `data/demo_sop.txt`: fictional training SOP for the mini-RAG demonstration.
- `reports/Jan_Samadhan_Capstone_Report.docx` and `.pdf`: professional case-study report.
- `requirements.txt`: Python dependencies.

## Run locally
Recommended: Python 3.10–3.13 (Gradio and scientific Python package compatibility may vary on newer Python versions).

Windows PowerShell:
```powershell
py -3.12 -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
python app.py
```

macOS/Linux:
```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
python app.py
```
Gradio prints the local URL in the terminal. The app chooses an available port automatically. `share=False` keeps it local.

## Important limitations
1. The dataset is entirely synthetic. It contains no real CPGRAMS or citizen records.
2. Labels are generated for demonstration; model metrics are not evidence of production accuracy.
3. The complaint summary and acknowledgment are template/extractive demonstrations. The app does not call an external LLM. The C.R.O.S.S. prompt is supplied for an approved LLM integration.
4. Mini-RAG uses TF-IDF retrieval over the fictional SOP and returns retrieved passages. It is a transparent retrieval-grounded simulation, not a production LLM.
5. PII regex masking is partial and can miss variants. Use approved DLP, validation, secure storage, and authorized infrastructure for real deployment.
6. Predictions and drafts are advisory only; an authorized officer must review every case.

## Project workflow
CSV → Pandas cleaning → visual analytics → train/test split → TF-IDF → Logistic Regression → prediction/evaluation → PII masking → C.R.O.S.S. prompt → SOP retrieval → officer review.
